package dailyprogram;

public class Code_34 {

	public static void main(String[] args) {
		/*Write a simple Java program to print 111, 222, 333, 444, 555, 666, 777, 888, 999.*/
		for (int i = 1; i < 10; i++) {
			System.out.println(i+""+i+""+i);
		}
	}
}
