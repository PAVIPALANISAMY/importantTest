# ExtentReportsExample
**ExtentReports 5** with TestNG Listeners and Retry Analyzer
Article Link: https://www.swtestacademy.com/extentreports-testng/

This project support latest version of ExtentReports, TestNG, and Selenium Libraries.
You can fork it and do you changes based on your requirements.

