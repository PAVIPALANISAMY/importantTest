package pages;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import tests.BaseTest;
import utils.logs.Log;

public class HomePage extends BasePage {
	
    /**
     * Constructor
     */
    public HomePage(WebDriver driver) {
        super(driver);
    }

    /**
     * Variables
     * @return 
     */
    //Read URL from Config File
    public String getURL() throws IOException {
    	FileReader reader=new FileReader("./src/test/resources/config.properties");  
        Properties p=new Properties();  
        p.load(reader);
        return p.getProperty("url");
              
    }
    /**
     * Web Elements
     */
    By SignInBtn = By. linkText("Sign In");

    /**
     * Page Methods
     * @param baseURL2 
     * @throws IOException 
     */
    //Go to Homepage
    public HomePage goToHomePage() throws IOException  {
        Log.info("Opening Website :"+getURL());
        driver.get(getURL());
        return this;
    }

    //Go to LoginPage
    public LoginPage goToLoginPage() {
        Log.info("Going to Login Page..");
        click(SignInBtn);
        return new LoginPage(driver);
    }
}