package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utils.logs.Log;

public class LoginPage extends BasePage {
    /**
     * Constructor
     */
    public LoginPage(WebDriver driver) {
    	super(driver);
    }

    /**
     * Web Elements
     */
    By uName = By.xpath("//input[@id='signInName']");
    By pswd = By.xpath("//input[@id='password']");
    By loginBtn = By.xpath("//button[@type='submit']");
  
    /**
     * Page Methods
     */
    public LoginPage loginWithData(String username, String password) {
    	System.out.println("first");
        Log.info("Trying to login the Valid Credentials.");
        //System.out.println(driver.getTitle());
        System.out.println("second");
        //WebDriverWait wait = new WebDriverWait(driver,60);
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInName']")));
        //driver.findElement(uName).clear();
        driver.findElement(uName).sendKeys(username);
        //driver.findElement(pswd).clear();
        driver.findElement(pswd).sendKeys(password);
        driver.findElement(loginBtn).click();
        return this;
    }
  //Verify Page Title After valid Login
    public LoginPage verifyPageTitleAfterLogin() {
    	Log.info("Verifing Page Title after login with valid credentials");
		String PgTitle=driver.getTitle();
		System.out.println(PgTitle);
		String expected="Example Domain--";
		Assert.assertEquals(PgTitle, expected);
		return this;
	
}
}