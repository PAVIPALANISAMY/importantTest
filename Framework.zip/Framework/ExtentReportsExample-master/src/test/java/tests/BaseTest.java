package tests;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import pages.HomePage;
import utils.logs.Log;
import utils.readexcel.DataProviderTest;

public class BaseTest extends DataProviderTest {
    
    
	
    
    public WebDriver driver;
    public HomePage  homePage;
    public String browser;
    
    public WebDriver getDriver() {
        return driver;
    }
    
    public String getBrowserName() throws IOException {
    	FileReader reader=new FileReader("./src/test/resources/config.properties");  
        Properties p=new Properties();  
        p.load(reader);
        return p.getProperty("browser");
     
    }
    
   @BeforeClass
    public void classLevelSetup() throws IOException {
        Log.info("Tests is starting!");
        switch(getBrowserName()) {
        case "Chrome":
        	System.setProperty("webdriver.chrome.driver","./resource/Drivers/chromedriver_win32/chromedriver.exe");
            driver = new ChromeDriver();
          break;
        case "FireFox":
        	System.setProperty("webdriver.gecko.driver","./resource/Drivers/geckodriver_win32/geckodriver.exe");
        	driver = new FirefoxDriver();
          break;
        default:
        	System.setProperty("webdriver.gecko.driver","./resource/Drivers/geckodriver_win32/geckodriver.exe");
        	driver = new FirefoxDriver();
      }
        
    }

    @BeforeMethod
    public void methodLevelSetup() {
        homePage = new HomePage(driver);
    }

    @AfterClass
    public void teardown() {
        Log.info("Tests are ending!");
        driver.quit();
    }
}