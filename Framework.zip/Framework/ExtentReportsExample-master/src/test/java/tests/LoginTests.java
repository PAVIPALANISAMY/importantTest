package tests;

import static utils.extentreports.ExtentTestManager.startTest;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest  {
    @Test(priority = 0, description = "Invalid Login Scenario with wrong username and password.",dataProvider ="LoginData")
    public void LoginTest_validUserNameandPassword(String sUsername, String sPassword,Method method) throws IOException {
        //ExtentReports Description
       startTest(method.getName(), "Login Scenario with valid username and password.");

        homePage
            .goToHomePage()
            .goToLoginPage()
           .loginWithData(sUsername,sPassword)
           .verifyPageTitleAfterLogin();

 }
}