package utils.extentreports;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {
    public static final ExtentReports extentReports = new ExtentReports();

    public synchronized static ExtentReports createExtentReports() {
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMddHHmmss");  
        LocalDateTime now = LocalDateTime.now();
        ExtentSparkReporter reporter = new ExtentSparkReporter("./extent-reports/Reports/extent-report_"+dtf.format(now)+".html");
        reporter.config().setReportName("Extent Report-Personal");
        extentReports.attachReporter(reporter);
        extentReports.setSystemInfo("Karthik", "Testing");
        return extentReports;
    }
}
