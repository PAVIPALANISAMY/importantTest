package utils.listeners;



import static utils.extentreports.ExtentTestManager.getTest;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import com.aventstack.extentreports.Status;

import tests.BaseTest;

public class Retry implements IRetryAnalyzer {

    private        int count  = 0;
    private static int maxTry = 1; //Run the failed test 2 times

    @Override
    public boolean retry(ITestResult iTestResult) {
        if (!iTestResult.isSuccess()) {                     //Check if test not succeed
            if (count < maxTry) {                           //Check if maxTry count is reached
                count++;                                    //Increase the maxTry count by 1
                iTestResult.setStatus(ITestResult.FAILURE); //Mark test as failed and take base64Screenshot
                try {
					extendReportsFailOperations(iTestResult);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}   //ExtentReports fail operations
                return true;                                //Tells TestNG to re-run the test
            }
        } else {
            iTestResult.setStatus(ITestResult.SUCCESS);     //If test passes, TestNG marks it as passed
        }
        return false;
    }

    public void extendReportsFailOperations(ITestResult iTestResult) throws IOException {
        Object testClass = iTestResult.getInstance();
        WebDriver webDriver = ((BaseTest) testClass).getDriver();
        TakesScreenshot ts = (TakesScreenshot)webDriver;
        File source = ts.getScreenshotAs(OutputType.FILE);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMddHHmmss");  
        LocalDateTime now = LocalDateTime.now();  
        String dest = System.getProperty("user.dir") +"\\extent-reports\\Screenshots\\"+dtf.format(now)+".png";
        File destination = new File(dest);
        FileUtils.copyFile(source, destination);
        getTest().log(Status.FAIL, "Test Failed",
        		getTest().addScreenCaptureFromPath(dest).getModel().getMedia().get(0));
       
    }
}
