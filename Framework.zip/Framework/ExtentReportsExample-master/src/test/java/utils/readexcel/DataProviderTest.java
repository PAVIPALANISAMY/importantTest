package utils.readexcel;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class DataProviderTest extends ReadDataFromExcel{
	

	@DataProvider(name ="LoginData")
  	public Object[][] excelDP() throws IOException{
        	//We are creating an object from the excel sheet data by calling a method that reads data from the excel stored locally in our system
        	Object[][] arrObj = getExcelData("./resource/Excel-Files/TestData.xlsx","Login");
        	return arrObj;
  	}
  	//This method handles the excel - opens it and reads the data from the respective cells using a for-loop & returns it in the form of a string array
}
